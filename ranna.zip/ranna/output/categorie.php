<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        <!-- section1 -->
        <section class="section1 bg-gold">
            <div class="container pt-5 pb-5">
                <div class="row pt-5 pb-5">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white h2 font-weight-bold left-reveal">Categorie</h1>
                        <h6 class="mt-4 right-reveal">
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-home mr-2"></i>Home</a> 
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-chevron-right fa-sm mr-2"></i>Categories</a> 
                            <span class="text-light"> <small><i class="fa fa-chevron-right fa-sm mr-2"></i></small> Categorie </span>
                        </h6>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- section7 -->
        <section class="section7">
            <div class="col-md-11 mx-auto">
                <div class="row text-left pb-5 mt-4">
                    <div class="col-12 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="recipes.php">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 rounded-lg child">
                                        <div class="pl-3 pt-4 opacity2 pbb4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4 align-self-center">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="rounded-lg d-md-flex mt-4">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-12 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="recipes.php">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 rounded-lg child">
                                        <div class="pl-3 pt-4 opacity2 pbb4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4 align-self-center">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="rounded-lg d-md-flex mt-4">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="recipes.php">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 rounded-lg child">
                                        <div class="pl-3 pt-4 opacity2 pbb4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4 align-self-center">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="rounded-lg d-md-flex mt-4">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="recipes.php">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 rounded-lg child">
                                        <div class="pl-3 pt-4 opacity2 pbb4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4 align-self-center">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="rounded-lg d-md-flex mt-4">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="recipes.php">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 rounded-lg child">
                                        <div class="pl-3 pt-4 opacity2 pbb4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4 align-self-center">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="rounded-lg d-md-flex mt-4">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          

</body>
</html>