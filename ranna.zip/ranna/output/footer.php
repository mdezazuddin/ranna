  
<!--footer-->
<footer class="bg-black2 foot">
    <div class="col-md-11 mx-auto py-5">
        <div class="row py-5 text-center">
            <div class="col-md-9 mx-auto">
                <div class="text-center left-reveal">
                    <a class="navbar-brand" href="index.php"><img class="mx-auto d-block" src="assets/image/logo-light.png"></a>
                </div>
            
                <div class="row mt-5 right-reveal">
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-facebook fa-lg mr-1"></i>
                        <small>0 FANS</small>
                    </a>
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-twitter fa-lg mr-1"></i>
                        <small>0 FOLLOWERS</small>
                    </a>
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-instagram fa-lg mr-1"></i>
                        <small>0 FOLLOWERS</small>
                    </a>
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-youtube fa-lg mr-1"></i>
                        <small>0 SUBSCRIBER</small>
                    </a>
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-pinterest fa-lg mr-1"></i>
                        <small>0 FOLLOWERS</small>
                    </a>
                    <a href="#" class="col-lg-2 col-md-4 text-decoration-none mt-3">
                        <i class="fa fa-linkedin fa-lg mr-1"></i>
                        <small>0 FOLLOWERS</small>
                    </a>
                </div>

                <div class="text-center mt-5 left-reveal">
                    <p class="text-grey">© 2020 Ranna. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>


<!--scroll-top-->
<div>
    <a class="scroll-top" href="#"><i class="fa fa-chevron-up bg-danger text-white p-3 mb-5 rounded-pill"></i></a>
</div>  
   
