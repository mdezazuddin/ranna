	
	<!--header-->
	<div class="col-md-11 mx-auto d-lg-block d-none pl-2">
		<div class="row py-2">
			<div class="col-md-3 align-self-center">
                <div class="d-flex">
                    <a href="#" class="text-decoration-none text-hvr">
                        <i class="fa fa-pinterest footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-hvr">
                        <i class="fa fa-twitter footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-hvr">
                        <i class="fa fa-facebook footer-icon"></i>
					</a>
					<a href="#" class="text-decoration-none ml-4 text-hvr">
                        <i class="fa fa-instagram footer-icon"></i>
                    </a>
                </div>
            </div>
			<div class="col-md-6 text-center">
				<a class="navbar-brand" href="index.php"><img src="assets/image/logo.png"></a>
			</div>
			<div class="col-md-3 align-self-center">
				<div class="d-flex justify-content-end">
                    <a href="#" class="text-decoration-none text-hvr mr-2" data-toggle="modal" data-target="#myModal">
                        <i class="fa fa-search fa-lg footer-icon"></i>
					</a>
					<span class="text-grey">|</span>
                    <a href="#" class="text-decoration-none ml-2 text-hvr">
                        <i class="fa fa-shopping-bag fa-lg footer-icon"></i>
                    </a>
                </div>
			</div>
		</div>
	</div>
	<hr class="my-0">
	
	<nav class="navbar navbar-expand-lg px-md-0 py-3 nav1">
		<div class="container-fluid mx-md-5 pl-0">
			<a class="navbar-brand d-none log1" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
			<a class="navbar-brand d-lg-none d-block log2" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
			<div class="d-lg-none d-block ml-auto">
				<div class="d-flex">
					<a href="#" class="btn btn-outline-danger rounded-pill d-md-block d-none"><small class="font-weight-bold"> Submit Recipe</small></a>
				</div>
			</div>
			<button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav mll2">
					<li>
						<a href="index.php">Home</a>
					</li>
					
					<li>
						<a href="categories.php" class="dropdown-toggle">Recipes</a>
						<ul>
							<li>
								<a href="index.php">Home</a>
							</li>
							<li>
								<a href="categories.php">Categories</a>
							</li>
							<li>
								<a href="recipes.php">Recipes</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="contact.php">Contact</a>
					</li>    
				</ul>
			</div>  

			<div class="d-lg-block d-none">
				<div class="d-flex">
					<a href="submit-recipe.php" class="btn btn-danger px-4 py-2 bg-gold rounded-pill"><small class="font-weight-bold"><i class="fa fa-plus fa-lg mr-2 my-2"></i> Submit Recipe</small></a>
				</div>
			</div>
		</div>
	</nav>



		<!-- search -->
        <div class="modal fade" id="myModal">
            <button type="button" class="close pb-3 px-3 pt-2 text-white mt-3 bg-danger" data-dismiss="modal">&times;</button>
            <div class="modal-dialog modal-lg">
                <div class="modal-content mtt2">
                    <div class="input-group">
                        <input type="text" class="form-control form-control-lg pp2" placeholder="Search">
                        <div class="input-group-append">
                            <button class="btn btn-danger btn-lg px-4" type="submit"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- loading -->
        <div class="modals" id="myModal1">
            <div class="text-center mtt2">
                <div class="spinner-border spinner-border-lg text-light" style="width: 80px; height: 80px;"></div>
            </div>
        </div>