<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section1 -->
        <section class="section1">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-12 pl-0 pr-0">
                        <!-- Swiper -->
                        <div class="swiper-container mt-2 hvr-arrow swiper1">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide rounded-lg pt-5 bg-img1"><br><br><br><br><br><br><br>
                                    <div class="col-md-6 p-5 text-center mx-auto mt-5 bg-white hvr-top">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa and Avocado Salad</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">2</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that is seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-comment-o text-gold mr-1"></i>
                                                <small>3</small>
                                            </a>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide rounded-lg pt-5 bg-img2"><br><br><br><br><br><br><br>
                                    <div class="col-md-6 p-5 text-center mx-auto mt-5 bg-white">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa and Avocado Salad</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">3</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-comment-o text-gold mr-1"></i>
                                                <small>3</small>
                                            </a>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide rounded-lg pt-5 bg-img3"><br><br><br><br><br><br><br>
                                    <div class="col-md-6 p-5 text-center mx-auto mt-5 bg-white">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa and Avocado Salad</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-comment-o text-gold mr-1"></i>
                                                <small>3</small>
                                            </a>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div><br>
                            
                            <!-- Add Arrows -->
                            <div class="swiper-button-next swiper-button-white btns8-right"></div>
                            <div class="swiper-button-prev swiper-button-white btns8-left"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-md-4 mt-4 left-reveal">
                        <div class="text-center parent">
                            <a href="#">
                                <div class="parent">
                                    <div class="bg-img1 child rounded-lg p-5">
                                        <div class="p-5 m-4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <h5 class="text-gold h6"><b>Rezala</b></h5>
                                <a class="text-hvr text-decoration-none" href="#"><h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2></a>
                                <div class="d-flex justify-content-center mt-3">
                                    <div class="mr-3">
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-grey"></i>
                                    </div>
                                    <span>
                                        <span class="text-body">4</span><span class="text-muted">/5</span>
                                    </span>
                                </div>
                                <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that is
                                    seasoned, stacked in
                                    a cone</p>
                                <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                    <a href="#" class="text-decoration-none text-hvr mr-3">
                                        <i class="fa fa-user text-gold mr-1"></i>
                                        <small>by Jack Blacks</small>
                                    </a>
                                    <span class="mr-3">
                                        <i class="fa fa-clock-o text-gold mr-1"></i>
                                        <small class="text-muted">55 Min</small>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mt-4 top-reveal">
                        <div class="text-center parent">
                            <a href="#">
                                <div class="parent">
                                    <div class="bg-img2 child rounded-lg p-5">
                                        <div class="p-5 m-4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <h5 class="text-gold h6"><b>Rezala</b></h5>
                                <a class="text-hvr text-decoration-none" href="#">
                                    <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                </a>
                                <div class="d-flex justify-content-center mt-3">
                                    <div class="mr-3">
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-grey"></i>
                                    </div>
                                    <span>
                                        <span class="text-body">4</span><span class="text-muted">/5</span>
                                    </span>
                                </div>
                                <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                    is
                                    seasoned, stacked in
                                    a cone</p>
                                <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                    <a href="#" class="text-decoration-none text-hvr mr-3">
                                        <i class="fa fa-user text-gold mr-1"></i>
                                        <small>by Jack Blacks</small>
                                    </a>
                                    <span class="mr-3">
                                        <i class="fa fa-clock-o text-gold mr-1"></i>
                                        <small class="text-muted">55 Min</small>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mt-4 right-reveal">
                        <div class="text-center parent">
                            <a href="#">
                                <div class="parent">
                                    <div class="bg-img3 child rounded-lg p-5">
                                        <div class="p-5 m-4"></div>
                                    </div>
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <h5 class="text-gold h6"><b>Rezala</b></h5>
                                <a class="text-hvr text-decoration-none" href="#">
                                    <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                </a>
                                <div class="d-flex justify-content-center mt-3">
                                    <div class="mr-3">
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-grey"></i>
                                    </div>
                                    <span>
                                        <span class="text-body">4</span><span class="text-muted">/5</span>
                                    </span>
                                </div>
                                <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                    is
                                    seasoned, stacked in
                                    a cone</p>
                                <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                    <a href="#" class="text-decoration-none text-hvr mr-3">
                                        <i class="fa fa-user text-gold mr-1"></i>
                                        <small>by Jack Blacks</small>
                                    </a>
                                    <span class="mr-3">
                                        <i class="fa fa-clock-o text-gold mr-1"></i>
                                        <small class="text-muted">55 Min</small>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-12 col-lg-8">
                        <div class="left-reveal">
                            <h4 class="mt-5"><b>Trending Recipes</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>

                        <div class="text-center parent mt-4 left-reveal">
                            <a href="#">
                                <div class="parent">
                                    <div class="bg-img3 child rounded-lg p-5">
                                        <div class="p-5 m-5"><p class="p-5"></p></div>
                                    </div>
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <h5 class="text-gold h6"><b>Rezala</b></h5>
                                <a class="text-hvr text-decoration-none" href="#">
                                    <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                </a>
                                <div class="d-flex justify-content-center mt-3">
                                    <div class="mr-3">
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-grey"></i>
                                    </div>
                                    <span>
                                        <span class="text-body">4</span><span class="text-muted">/5</span>
                                    </span>
                                </div>
                                <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                    is
                                    seasoned, stacked in
                                    a cone</p>
                                <div class="col-md-6 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                    <a href="#" class="text-decoration-none text-hvr mr-3">
                                        <i class="fa fa-user text-gold mr-1"></i>
                                        <small>by Jack Blacks</small>
                                    </a>
                                    <span class="mr-3">
                                        <i class="fa fa-clock-o text-gold mr-1"></i>
                                        <small class="text-muted">55 Min</small>
                                    </span>
                                    <a href="#" class="text-decoration-none text-hvr">
                                        <i class="fa fa-heart-o text-gold mr-1"></i>
                                        <small>12 Likes</small>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mt-4 left-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img1 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="col-md-6 mt-4 right-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img2 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that
                                            is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="col-md-6 mt-4 left-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img3 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that
                                            is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mt-4 right-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img3 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that
                                            is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 mt-4 left-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img3 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that
                                            is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 mt-4 right-reveal">
                                <div class="text-center parent">
                                    <a href="#">
                                        <div class="parent">
                                            <div class="bg-img3 child rounded-lg p-5">
                                                <div class="p-5 m-4"></div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <h5 class="text-gold h6"><b>Rezala</b></h5>
                                        <a class="text-hvr text-decoration-none" href="#">
                                            <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">4</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that
                                            is
                                            seasoned, stacked in
                                            a cone</p>
                                        <div class="mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <a href="#" class="text-decoration-none text-hvr mr-3">
                                                <i class="fa fa-user text-gold mr-1"></i>
                                                <small>by Jack Blacks</small>
                                            </a>
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Min</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <img class="w-100 mt-4 left-reveal" src="assets/image/figure1.jpg">
                    </div>


                    <div class="col-12 col-lg-4">
                        <div class="right-reveal">
                            <h4 class="mt-5"><b>About Me</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <div class="text-center right-reveal">
                                <img class="mt-4" src="assets/image/about-you_250x250.jpg">
                                <img class="mt-4" src="assets/image/signature.png">
                                <p class="mt-3">Fusce mauris auctor ollicituder teary iner hendrerit risusey aeenean rauctor mauris pibus doloer.</p>
                            </div>

                            <div class="right-reveal">
                                <h4 class="mt-5 h5"><b>Subscribe & Follow</b></h4>
                                <div class="progress mt-3" style="height: 2px;">
                                    <div class="progress-bar bg-gold" style="width:20%;"></div>
                                </div>
                            </div>
                            <div class="mt-4 row">
                                <div class="col-md-6 left-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                        <i class="fa fa-facebook fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                                <div class="col-md-6 pl-md-0 right-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                        <i class="fa fa-twitter fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                                <div class="col-md-6 left-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                        <i class="fa fa-youtube fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                                <div class="col-md-6 pl-md-0 right-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                        <i class="fa fa-instagram fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                                <div class="col-md-6 left-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                       <i class="fa fa-pinterest fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                                <div class="col-md-6 pl-md-0 right-reveal">
                                    <a class="btn btn-light btns8 rounded-0 w-100 text-left py-3 text-black1 border border-muted mt-2" href="#">
                                        <i class="fa fa-linkedin fa-lg mr-1"></i>
                                        <small>0 FANS</small>
                                    </a>
                                </div>
                            </div>

                            <div class="right-reveal">
                                <h4 class="mt-5 h5"><b>Latest Recipes</b></h4>
                                <div class="progress mt-3" style="height: 2px;">
                                    <div class="progress-bar bg-gold" style="width:20%;"></div>
                                </div>
                            </div>
                            <div class="row mt-4 pt-2 parent right-reveal">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <div class="child bg-img1 p-5">
                                            
                                        </div>
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <h6 class="mb-0 text-gold small"><b>Pasta</b></h6>
                                    <a class="text-hvr" href="#">
                                        <h6 class="mb-0 mt-2"><b>Spiced Pork and Pasta</b></h6>
                                    </a>
                                    <p class="text-muted mt-2">
                                        <small><i class="fa fa-clock-o fa-lg text-gold mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-4 parent right-reveal">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <div class="child bg-img2 p-5">
                            
                                        </div>
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <h6 class="mb-0 text-gold small"><b>Pasta</b></h6>
                                    <a class="text-hvr" href="#">
                                        <h6 class="mb-0 mt-2"><b>Spiced Pork and Pasta</b></h6>
                                    </a>
                                    <p class="text-muted mt-2">
                                        <small><i class="fa fa-clock-o fa-lg text-gold mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-4 parent right-reveal">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <div class="child bg-img3 p-5">
                            
                                        </div>
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <h6 class="mb-0 text-gold small"><b>Pasta</b></h6>
                                    <a class="text-hvr" href="#">
                                        <h6 class="mb-0 mt-2"><b>Spiced Pork and Pasta</b></h6>
                                    </a>
                                    <p class="text-muted mt-2">
                                        <small><i class="fa fa-clock-o fa-lg text-gold mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <img class="w-100 mt-5 right-reveal" src="assets/image/figure2.jpg">

                            <div class="right-reveal">
                                <h4 class="mt-5 h5"><b>Recipe Categories</b></h4>
                                <div class="progress mt-3" style="height: 2px;">
                                    <div class="progress-bar bg-gold" style="width:20%;"></div>
                                </div>
                            </div>
                            <div class="mt-4 right-reveal">
                                <a class="text-hvr text-decoration-none mt-4 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Drink</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Intro</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Drink</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Intro</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Drink</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Intro</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Drink</span><span>3</span>
                                </a>
                                <a class="text-hvr text-decoration-none mt-2 p-2 d-flex justify-content-between" href="#">
                                    <span class="hvr-icon"><span class="widd4"></span>Intro</span><span>3</span>
                                </a>
                            </div>
                        </div>
        
                        <div class="bg-light p-5 mt-5 rounded-lg text-center right-reveal">
                            <h4 class="mt-2 h5"><b>Get Lastest Updates</b></h4>
                            <hr>
                            <div class="mt-4 text-dark">
                                <p class="small mt-4 text-muted">Newsletter Subscribe</p>
                                <form class="">
                                    <input class="form-control p-4 text-center bg-white border-0" type="text" name="name" placeholder="Enter Your Email">
                                    <button class="btn btn-danger bg-gold btn-lg bg-green w-100 mt-3 text-white" type="button"><small
                                            class="font-weight-bold">Subscribe</small></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-md-12 left-reveal">
                        <h4 class="mt-5"><b>Editor's Choice</b></h4>
                        <div class="progress mt-3" style="height: 2px;">
                            <div class="progress-bar bg-gold" style="width:20%;"></div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="text-decoration-none d-flex flex-column" href="#">
                            <div class="parent rounded-lg">
                                <div class="layers ptt1 mt-3 ml-4 mr-4 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex justify-content-center mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex justify-content-center p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-grey">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr1">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img1 rounded-lg child pl-3 pt-4 pbb1" style="filter: brightness(45%);"></div>
                            </div>
                        </a>
                    </div>
        
                    <div class="col-12 col-lg-4 mt-4 bottom-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="text-decoration-none d-flex flex-column" href="#">
                            <div class="parent rounded-lg">
                                <div class="layers ptt1 mt-3 ml-4 mr-4 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex justify-content-center mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex justify-content-center p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-grey">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr1">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img2 rounded-lg child pl-3 pt-4 pbb1" style="filter: brightness(45%);"></div>
                            </div>
                        </a>
                    </div>
        
                    <div class="col-12 col-lg-4 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="text-decoration-none d-flex flex-column" href="#">
                            <div class="parent rounded-lg">
                                <div class="layers ptt1 mt-3 ml-4 mr-4 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex justify-content-center mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex justify-content-center p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-grey">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr1">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img3 rounded-lg child pl-3 pt-4 pbb1" style="filter: brightness(45%);"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2 mt-3">
            <div class="col-md-11 mx-auto pb-5">
                <div class="row">
                    <div class="col-12 col-lg-8">
                        <div class="left-reveal">
                            <h4 class="mt-5"><b>Popular Recipes</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>

                        <div class="row mt-4 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="#">
                                <div class="parent rounded-lg">
                                    <div class="bg-img1 pbb2 rounded-lg child pl-3 pt-4"></div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="col-md-10 rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div class="row mt-5 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="#">
                                <div class="parent rounded-lg">
                                    <div class="bg-img2 pbb2 rounded-lg child pl-3 pt-4"></div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="col-md-10 rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div class="row mt-5 parent left-reveal">
                            <a class="col-md-5 pr-md-0 text-decoration-none" href="#">
                                <div class="parent rounded-lg">
                                    <div class="bg-img3 pbb2 rounded-lg child pl-3 pt-4"></div>
                                </div>
                            </a>
                            <div class="col-md-7 mt-md-0 mt-4">
                                <div class="card-body">
                                    <h5 class="text-gold h6"><b>Rezala</b></h5>
                                    <a class="text-hvr text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchi Recipes Sultan Kacchi Recipes</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-grey"></i>
                                        </div>
                                        <span>
                                            <span class="text-body">4</span><span class="text-muted">/5</span>
                                        </span>
                                    </div>
                                    <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that
                                        is
                                        seasoned, stacked in
                                        a cone</p>
                                    <div class="col-md-10 rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                        <a href="#" class="text-decoration-none text-hvr mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                        <span class="mr-3">
                                            <i class="fa fa-clock-o text-gold mr-1"></i>
                                            <small class="text-muted">55 Min</small>
                                        </span>
                                        <a href="#" class="text-decoration-none text-hvr">
                                            <i class="fa fa-heart-o text-gold mr-1"></i>
                                            <small>12 Likes</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="right-reveal">
                            <h4 class="mt-5 h5"><b>Featured Article</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>
                        <!-- Swiper -->
                        <div class="swiper-container mt-4 hvr-arrow1 swiper1 right-reveal">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <a href="#"><div class="rounded-lg p-5 bg-img1">
                                        <div class="p-5 m-4"></div>
                                    </div></a>
                                    <div class="col-md-10 p-4 text-center mtt1 mx-auto mt-5 bg-white hvr-top">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr h5 text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">2</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that is seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="rounded-lg p-5 bg-img2">
                                            <div class="p-5 m-4"></div>
                                        </div>
                                    </a>
                                    <div class="col-md-10 p-4 text-center mtt1 mx-auto mt-5 bg-white hvr-top">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr h5 text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">2</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that is seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="rounded-lg p-5 bg-img3">
                                            <div class="p-5 m-4"></div>
                                        </div>
                                    </a>
                                    <div class="col-md-10 p-4 text-center mtt1 mx-auto mt-5 bg-white hvr-top">
                                        <h5 class="text-gold h6"><b>Breakfast</b></h5>
                                        <a class="text-hvr h5 text-decoration-none" href="#">
                                            <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                        </a>
                                        <div class="d-flex justify-content-center mt-3">
                                            <div class="mr-3">
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-warning"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                                <i class="fa fa-star text-grey"></i>
                                            </div>
                                            <span>
                                                <span class="text-body">2</span><span class="text-muted">/5</span>
                                            </span>
                                        </div>
                                        <p class="mt-3 text-muted">The doner is a Turkish creation of meat, often lamb, but not necessarily so,
                                            that is seasoned, stacked in
                                            a cone</p>
                                        <div class="col-md-10 mx-auto rounded-lg d-md-flex justify-content-center bg-light p-3 mt-2">
                                            <span class="mr-3">
                                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                                <small class="text-muted">55 Minutes</small>
                                            </span>
                                            <a href="#" class="text-decoration-none text-hvr">
                                                <i class="fa fa-heart-o text-gold mr-1"></i>
                                                <small>12 Likes</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div><br>
                        
                            <!-- Add Arrows -->
                            <div class="swiper-button-next swiper-button-white btns8-right1"></div>
                            <div class="swiper-button-prev swiper-button-white btns8-left1"></div>
                        </div>
        
        
                        <div class="right-reveal">
                            <h4 class="mt-2 h5"><b>Popular Tag</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <a class="btn btn-light btns8 py-2 rounded left-reveal text-black1 border border-muted mt-2" href="#">
                                Burger
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded right-reveal text-black1 border border-muted mt-2" href="#">
                                Cake
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded left-reveal text-black1 border border-muted mt-2" href="#">
                                Dinner
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded right-reveal text-black1 border border-muted mt-2" href="#">
                                Lunch
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded left-reveal text-black1 border border-muted mt-2" href="#">
                                Night
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded right-reveal text-black1 border border-muted mt-2" href="#">
                                Pizza
                            </a>
                            <a class="btn btn-light btns8 py-2 rounded left-reveal text-black1 border border-muted mt-2" href="#">
                                Salaad
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <!-- section2 -->
        <section class="section2">
            <div class="container-fluid mt-4">
                <div class="row">
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img2">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
            
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent top-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img1">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
            
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent bottom-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img2">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
            
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent top-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img1">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
            
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent bottom-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img2">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
            
                    <div class="col-12 col-md-4 col-lg-2 p-0 parent left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <div class="con5 w-100 pt-5 p-5 bg-img1">
                                <div class="p-5"></div>
                                <div class="overlay5">
                                    <div class="text5">
                                        <i class="fa fa-instagram"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>
    

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>