$(function(){
// fixed-scroll-top
    $(window).scroll(function(){
      if($(window).scrollTop() >= 600){
        $('.scroll-top').css('display','block')
      }else{
        $('.scroll-top').css('display','none')
      }
    });   


// call-scroll-top
    $(document).ready(function(){
      $(".scroll-top").click(function(){
        $("html,body").animate({
          scrollTop: 0
        });
        return false
      });
    });
 

/* Preloading animation
    $(window).on("load", function() {
      preloaderFadeOutTime = 500;
      function hidePreloader() {
        var preloader = $('#myModal1');
          preloader.fadeOut(preloaderFadeOutTime);
      }
      hidePreloader();
    }); */


    // loading 
    $(document).ready(function () {
      preloaderFadeOutTime = 500;
      function hidLoader(){
        var loader = $('#myModal1');
        loader.fadeOut(preloaderFadeOutTime);
      }
      hidLoader();
    });


    // menu active 
    var page = window.location.pathname.split('/')
    page = page[page.length - 1]
    var nav = document.querySelectorAll('a[href="' + page + '"]')
    nav.forEach(function(link,i){
      nav[i].classList.add('active')
    })
    //nav.classList.add('active')


// navbar-fixed    
    $(window).scroll(function(){
      if($(window).scrollTop() >= 600){
        $('.nav1').addClass('fixed-heade')
        $('.log1').addClass('add1')
        $('.log2').addClass('add2')
        $('.mll2').addClass('add3')
      }else{
        $('.nav1').removeClass('fixed-heade')
        $('.log1').removeClass('add1')
        $('.log2').removeClass('add2')
        $('.mll2').removeClass('add3')
      }
    });
    
    
  //page-scrollreveal
    window.sr = ScrollReveal();
    sr.reveal('.top-reveal',{
        origin: 'top',
        duration: 1200,
        distance: '15px',
        delay    : 200,
        easing: 'cubic-bezier(0.6, 0.2, 0.1, 1)'
    });
    sr.reveal('.bottom-reveal',{
        origin: 'bottom',
        duration: 1100,
        distance: '15px',
        delay    : 200,
        easing: 'cubic-bezier(0.6, 0.2, 0.1, 1)'
    });
    sr.reveal('.left-reveal',{
        scale: 0,
        origin: 'left',
        duration: 2000,
        delay    : 200,
        distance : '15px'
    });
    sr.reveal('.right-reveal',{
        origin: 'right',
        duration: 1600,
        distance: '15px',
        delay    : 200,
        easing: 'cubic-bezier(0.6, 0.2, 0.1, 1)'
    });
});