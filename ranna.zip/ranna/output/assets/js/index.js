$(function(){ 
    // swiper-master    
    var swiper1 = new Swiper('.swiper1', {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 1,


        autoplay: {
            delay: 5000,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            //dynamicBullets: true,
        },

        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },

    });
 });