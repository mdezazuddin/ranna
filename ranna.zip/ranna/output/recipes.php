<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        <!-- section1 -->
        <section class="section1 bg-gold">
            <div class="col-md-11 mx-auto pt-5 pb-5">
                <div class="row pt-5 pb-5">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white h2 font-weight-bold left-reveal">Sunday Best Fruit Salad with best recipe writer in the world</h1>
                        <h6 class="mt-4 right-reveal">
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-home mr-2"></i>Home</a> 
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-chevron-right fa-sm mr-2"></i>Categories</a>
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-chevron-right fa-sm mr-2"></i>Categorie</a> 
                            <span class="text-light"> <small><i class="fa fa-chevron-right fa-sm mr-2"></i></small> Recipies </span>
                        </h6>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- section1 -->
        <section class="section1">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-12">
                        <div class="row mt-5">
                            <div class="col-md-9 mt-4 left-reveal">
                                <span class="mr-3">
                                    <i class="fa fa-calendar text-gold mr-1"></i>
                                    <small class="text-muted">July 12, 2019</small>
                                </span>
                                <a href="#" class="text-decoration-none text-hvr mr-3">
                                    <i class="fa fa-user text-gold mr-1"></i>
                                    <small>By Jack Black</small>
                                </a>
                                <a href="#" class="text-decoration-none text-hvr mr-3">
                                    <i class="fa fa-heart-o text-gold mr-1"></i>
                                    <small>12 Likes</small>
                                </a>
                                <a href="#" class="text-decoration-none text-hvr mr-3">
                                    <i class="fa fa-tags text-gold mr-1"></i>
                                    <small>Dinner</small>
                                </a>
                                <span class="mr-3">
                                    <i class="fa fa-book text-gold mr-1"></i>
                                    <small>Cuisine:</small>
                                    <a href="#" class="text-decoration-none text-hvr">
                                        <small><i>Italian,</i></small>
                                    </a>
                                    <a href="#" class="text-decoration-none text-hvr">
                                        <small><i>Japanese,</i></small>
                                    </a>
                                    <a href="#" class="text-decoration-none text-hvr">
                                        <small> <i>Thai</i></small>
                                    </a>
                                </span>
                                <span>
                                    <i class="fa fa-signal text-gold mr-1"></i>
                                    <small class="text-muted">Difficulty: Medium</small>
                                </span>
                            </div>

                            <div class="col-md-3 mt-4 text-md-right right-reveal">
                                <a href="#" class="text-decoration-none text-hvr3">
                                    <i class="fa fa-share-alt fa-2x"></i>
                                </a>
                            </div>
                        </div>

                        <img class="w-100 mt-4 top-reveal" src="assets/image/img2.jpg">
                        <div class="row no-gutters text-md-left text-center">
                            <div class="col-12 col-lg-3 col-md-6 mt-md-0 mt-3 left-reveal border border-white">
                                <div class="bg-light p-4 rounded-lg w-100">
                                    <div class="row">
                                        <div class="col-md-2 align-self-center">
                                            <i class="fa fa-clock-o fa-2x text-gold"></i>
                                        </div>
                                        <div class="col-md-10">
                                            <h6 class="mb-1"><b>Prep Time</b></h6>
                                            <small>20 Mins</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-3 col-md-6 mt-md-0 top-reveal mt-3 border border-white">
                                <div class="bg-light p-4 rounded-lg w-100">
                                    <div class="row">
                                        <div class="col-md-2 align-self-center">
                                            <i class="fa fa-cutlery fa-2x text-gold"></i>
                                        </div>
                                        <div class="col-md-10">
                                            <h6 class="mb-1"><b>Cook Time</b></h6>
                                            <small>55 Mins</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-3 col-md-6 mt-md-0 bottom-reveal mt-3 border border-white">
                                <div class="bg-light p-4 rounded-lg w-100">
                                    <div class="row">
                                        <div class="col-md-2 align-self-center">
                                            <i class="fa fa-users fa-2x text-gold"></i>
                                        </div>
                                        <div class="col-md-10">
                                            <h6 class="mb-1"><b>Serving</b></h6>
                                            <small>4</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-3 col-md-6 mt-md-0 right-reveal mt-3 border border-white">
                                <div class="bg-light p-4 rounded-lg w-100">
                                    <div class="row">
                                        <div class="col-md-2 align-self-center">
                                            <i class="fa fa-eye fa-2x text-gold"></i>
                                        </div>
                                        <div class="col-md-10">
                                            <h6 class="mb-1"><b>View</b></h6>
                                            <small>646</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <p class="mt-5 left-reveal">The doner is a Turkish creation of meat, often lamb, but not necessarily so, that is seasoned, stacked in a cone shape,
                        and cooked slowly on a vertical rotisserie. As the outer layers of the meat cooks, it’s shaved off and served in a pita
                        or other flatbread with vegetables and sauce. Doner is the “mother,” as it were, of Arabic shawarma, Mexican al pastor,
                        and the popular Greek gyros. Although the sliced meat can be served on a platter with rice and cooked vegetables, it’s
                        most popular as a sandwich eaten as fast street food. You might find tomatoes, lettuce, cucumbers, red onion, cucumbers,
                        or pickles inside the pita, and the sauce might be Greek yogurt-based tzatziki or Middle Eastern tahini. Making an
                        authentic doner kebab at home can be a bit tricky although still possible if you have the set up for a slow cooking
                        vertical rotating spit. For most home kitchens, however, some improvisation will be required. But the flavors and spices
                        will be easier to recreate than the exact shape. You can form ground lamb into balls and thread them on skewers, but the
                        easiest way to get the sliced look of a street doner kebab is to make a sort of meatloaf.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-md-6 mt-4 left-reveal">
                        <div class="bg-light p-4">
                            <h4><i class="fa fa-list-ul text-gold fa-lg mr-3"></i><b>Ingredients</b></h4>
                            <div class="bg-white shadow p-4 mt-4">
                                <span class="p-2 pb-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1 lamb</span><b></b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1 oregano
                                    </span><b></b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1/2 salt
                                    </span><b></b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1/4 black pepper
                                    </span><b></b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1 kg Carroll
                                    </span><b></b>
                                </span>
                                <span class="p-2 pt-3 mb-4 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>1 piece Egg
                                    </span><b></b>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mt-4 right-reveal">
                        <div class="bg-light2 p-4">
                            <h4><i class="fa fa-info text-gold fa-lg mr-3"></i><b>Nutrition</b></h4>
                            <div class="bg-white shadow px-4 mt-4">
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon"><span class="widd4"></span></span><span>Daily Value*</span>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Total Fat: 45.8g</span><b>32%</b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Chlosterols: 224mg
</span><b>75%</b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Sodium: 149mg
</span><b>44%</b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Vitamin D: 1ng
</span><b>39%</b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Water : 150ml
</span><b>3%</b>
                                </span>
                                <span class="p-2 py-3 d-flex justify-content-between">
                                    <span class="hvr-icon h6"><span class="widd4"></span>Water : 150ml
                                    </span><b>3%</b>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <!-- section2 -->
        <section class="section2 mt-5">
            <div class="col-md-11 mx-auto bg-light py-5">
                <div class="row text-center">
                    <div class="col-md-12 left-reveal">
                        <h4><b>From Our Shop</b></h4>
                    </div>
                </div>
        
                <!-- Swiper -->
                <div class="swiper-container mx-md-5 mt-4 hvr-arrow1 swiper2">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="text-center con5">
                                <div class="con5 w-100 bg-white pt-5 p-5">
                                    <img class="w-100" src="assets/image/mug.png">
                                    <div class="overlay5">
                                        <div class="text5">
                                            <a href="#" class="btn btn-outline-light">
                                                <i class="fa fa-shopping-bag"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a class="text-hvr h5 text-decoration-none" href="#">
                                    <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                </a>
                                <h5 class="text-gold h6"><b>$125</b></h5>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="text-center con5">
                                <div class="con5 w-100 bg-white pt-5 p-5">
                                    <img class="w-100" src="assets/image/cup.png">
                                    <div class="overlay5">
                                        <div class="text5">
                                            <a href="#" class="btn btn-outline-light">
                                                <i class="fa fa-shopping-bag"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a class="text-hvr h5 text-decoration-none" href="#">
                                    <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                </a>
                                <h5 class="text-gold h6"><b>$125</b></h5>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="text-center con5">
                                <div class="con5 w-100 bg-white pt-5 p-5">
                                    <img class="w-100" src="assets/image/mug.png">
                                    <div class="overlay5">
                                        <div class="text5">
                                            <a href="#" class="btn btn-outline-light">
                                                <i class="fa fa-shopping-bag"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a class="text-hvr h5 text-decoration-none" href="#">
                                    <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                </a>
                                <h5 class="text-gold h6"><b>$125</b></h5>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="text-center con5">
                                <div class="con5 w-100 bg-white pt-5 p-5">
                                    <img class="w-100" src="assets/image/cup.png">
                                    <div class="overlay5">
                                        <div class="text5">
                                            <a href="#" class="btn btn-outline-light">
                                                <i class="fa fa-shopping-bag"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a class="text-hvr h5 text-decoration-none" href="#">
                                    <h2 class="mt-3 font-weight-bold">Kale Quinoa</h2>
                                </a>
                                <h5 class="text-gold h6"><b>$125</b></h5>
                            </div>
                        </div>
                    </div><br>
                
                    <!-- Add Arrows -->
                    <div class="swiper-button-next swiper-button-white btns8"></div>
                    <div class="swiper-button-prev swiper-button-white btns8"></div>
                </div>
            </div>
        </section>



        <!-- section2 -->
        <section class="section2">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-12">
                        <div class="left-reveal">
                            <h4 class="mt-5"><b>Directions</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:20%;"></div>
                            </div>
                        </div>
                        <p class="mt-4 right-reveal">You can make the kebab at home. The homemade version of your favourite Chicken Doner Kebab! Tastes remarkably similar to
                        the diner kebab meat from your favourite takeout store. I've baked it, but imagine it rotisserie style over the BBQ or
                        charcoal! You will need 4 long metal skewers for this, around 30cm / 12" long.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-1 mt-4 left-reveal">
                        <div class="breadcrumbs-two">
                            <span>Step1</span>
                        </div>
                    </div>
                    <div class="col-12 col-lg-11 mt-4">
                        <img class="w-100 right-reveal" src="assets/image/img1.jpg">
                        <p class="mt-4 left-reveal">You can make the kebab at home. The homemade version of your favourite Chicken Doner Kebab! Tastes
                            remarkably similar to
                            the diner kebab meat from your favourite takeout store. I've baked it, but imagine it rotisserie style over the BBQ
                            or
                            charcoal! You will need 4 long metal skewers for this, around 30cm / 12" long.</p>
                    </div>
                    <div class="col-12 col-lg-1 mt-4 left-reveal">
                        <div class="breadcrumbs-two">
                            <span>Step1</span>
                        </div>
                    </div>
                    <div class="col-12 col-lg-11 mt-4">
                        <img class="w-100 right-reveal" src="assets/image/img2.jpg">
                        <p class="mt-4 left-reveal">You can make the kebab at home. The homemade version of your favourite Chicken Doner Kebab! Tastes
                            remarkably similar to
                            the diner kebab meat from your favourite takeout store. I've baked it, but imagine it rotisserie style over the
                            BBQ
                            or
                            charcoal! You will need 4 long metal skewers for this, around 30cm / 12" long.</p>
                    </div>
                    <div class="col-12 col-lg-1 mt-4 left-reveal">
                        <div class="breadcrumbs-two">
                            <span>Step1</span>
                        </div>
                    </div>
                    <div class="col-12 col-lg-11 mt-4">
                        <img class="w-100 right-reveal" src="assets/image/img1.jpg">
                        <p class="mt-4 left-reveal">You can make the kebab at home. The homemade version of your favourite Chicken Doner Kebab! Tastes
                            remarkably similar to
                            the diner kebab meat from your favourite takeout store. I've baked it, but imagine it rotisserie style over the
                            BBQ
                            or
                            charcoal! You will need 4 long metal skewers for this, around 30cm / 12" long.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7 mt-4">
            <div class="col-md-11 mx-auto">
                <div class="border p-4">
                    <div class="row">
                        <div class="col-md-6 left-reveal">
                            <a href="#" class="btn btn-light btns8 rounded-0 py-2 px-3 bg-gold">
                                Dinner</a>
                            <a href="#" class="btn btn-light btns8 rounded-0 py-2 px-3 bg-gold">
                                    Salad</a>
                            <a href="#" class="btn btn-light btns8 rounded-0 py-2 px-3 bg-gold">
                                        Night</a>
                        </div>
                        <div class="col-md-6 mt-md-0 mt-4 text-md-right right-reveal">
                            <a href="#" class="btn btn-primary rounded-circle">
                                <i class="fa fa-facebook footer-icon"></i>
                            </a>
                            <a href="#" class="btn btn-info rounded-circle">
                                <i class="fa fa-twitter footer-icon"></i>
                            </a>
                            <a href="#" class="btn btn-danger rounded-circle">
                                <i class="fa fa-google footer-icon"></i>
                            </a>
                            <a href="#" class="btn btn-info rounded-circle">
                                <i class="fa fa-linkedin footer-icon"></i>
                            </a>
                            <a href="#" class="btn btn-danger rounded-circle">
                                <i class="fa fa-pinterest footer-icon"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7 my-4">
            <div class="col-md-11 mx-auto">
                <div class="row mt-4 pt-2 parent">
                    <div class="col-md-2 pr-md-0 left-reveal">
                        <img class="rounded-circle" src="assets/image/person1.jpeg">
                    </div>
                    <div class="col-md-10 pl-md-0 align-self-center right-reveal">
                        <a class="text-hvr text-decoration-none" href="#">
                            <h6 class="mb-2 mt-2"><b>Jack Black</b></h6>
                        </a>
                        <p class="mb-0 small">Recipe Writer</p>
                        <p class="text-muted mt-2">
                            I am an independent Recipe Collector and writer. I have tried more than 5000+ Recipes in my lifetime. I am using the
                            best WordPress Recipe Theme in the world. Name Ranna. I love food and recipe blogs to make life beautiful.
                        </p>
                        <div class="d-flex">
                            <a href="#" class="text-decoration-none text-hvr">
                                <i class="fa fa-pinterest footer-icon"></i>
                            </a>
                            <a href="#" class="text-decoration-none ml-4 text-hvr">
                                <i class="fa fa-twitter footer-icon"></i>
                            </a>
                            <a href="#" class="text-decoration-none ml-4 text-hvr">
                                <i class="fa fa-facebook footer-icon"></i>
                            </a>
                            <a href="#" class="text-decoration-none ml-4 text-hvr">
                                <i class="fa fa-instagram footer-icon"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7">
            <div class="col-md-11 mx-auto">
                <hr>
                <div class="row">
                    <div class="col-md-7 text-md-right left-reveal">
                        <h4 class="mt-3"><b>You May Also Like</b></h4>
                    </div>
                    
                    <div class="col-md-5 text-md-right mt-2 right-reveal">
                        <!-- Add Arrows -->
                        <div class="fa fa-angle-left fa-lg btns9"></div>
                        <div class="fa fa-angle-right fa-lg btns9"></div>
                    </div>
                </div>
                <hr>

                <!-- Swiper -->
                <div class="swiper-container mt-4 hvr-arrow1 swiper3">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="parent rounded-lg">
                                <div class="layers ptt2 mt-3 ml-3 mr-3 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchis</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="foot d-md-flex mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img1 rounded-lg child">
                                    <div class="pl-3 pt-4 opacity2 pbb3"></div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="parent rounded-lg">
                                <div class="layers ptt2 mt-3 ml-3 mr-3 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchis</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img1 rounded-lg child">
                                    <div class="pl-3 pt-4 opacity2 pbb3"></div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="parent rounded-lg">
                                <div class="layers ptt2 mt-3 ml-3 mr-3 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchis</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img1 rounded-lg child">
                                    <div class="pl-3 pt-4 opacity2 pbb3"></div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="parent rounded-lg">
                                <div class="layers ptt2 mt-3 ml-3 mr-3 mb-4">
                                    <a class="text-hvr1 text-decoration-none" href="#">
                                        <h2 class="mt-3 h5 font-weight-bold">Sultan Dines Kacchis</h2>
                                    </a>
                                    <div class="d-flex mt-3">
                                        <div class="mr-3">
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-warning"></i>
                                            <i class="fa fa-star text-light"></i>
                                        </div>
                                        <span>
                                            <span class="text-white">4</span><span class="text-light">/5</span>
                                        </span>
                                    </div>
                                    <div class="mx-auto foot d-md-flex mt-2">
                                        <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                            <i class="fa fa-user text-gold mr-1"></i>
                                            <small>by Jack Blacks</small>
                                        </a>
                                    </div>
                                </div>
                                <div class="bg-img1 rounded-lg child">
                                    <div class="pl-3 pt-4 opacity2 pbb3"></div>
                                </div>
                            </div>
                        </div>
                    </div><br>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/recipes.js"></script>

</body>
</html>