<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        <!-- section1 -->
        <section class="section1 bg-gold">
            <div class="container pt-5 pb-5">
                <div class="row pt-5 pb-5">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white h2 font-weight-bold left-reveal">Submit Recipe</h1>
                        <h6 class="mt-4 right-reveal">
                        <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-home mr-2"></i>Home</a> 
                        <span class="text-light"> <small><i class="fa fa-chevron-right fa-sm mr-2"></i></small> Recipe </span>
                        </h6>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- section2 -->
        <section class="section2 py-5">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="col-12">
                        <div class="bg-light3 p-md-5 p-3">
                            <h4><b>Submit Recipe</b></h4>
                            <div class="progress mt-md-4" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:7%;"></div>
                            </div>

                            <form name="frmSubmitRecipe" id="frmSubmitRecipe" method="post" action="#" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted">Name</label>
                                        <div class="bg-white p-2 mt-3" id="brdName" style="border: 2px solid white;">
                                            <input type="text" placeholder="Name" name="txtName" id="txtName" class="form-control border-0 shadow-none">
                                        </div>
                                        <span id="Nameerror" style="color: red;"></span>
                                    </div>
                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted">Email</label>
                                        <div class="bg-white p-2 mt-3" id="brdEmail" style="border: 2px solid white;">
                                            <input type="text" placeholder="Email" name="txtEmail" id="txtEmail" class="form-control border-0 shadow-none">
                                        </div>
                                        <span id="Emailerror" style="color: red;"></span>
                                    </div>
                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted">Phone</label>
                                        <div class="bg-white p-2 mt-3" id="brdPhone" style="border: 2px solid white;">
                                            <input type="text" maxlength="10" placeholder="Phone" name="txtPhone" id="txtPhone" class="form-control border-0 shadow-none">
                                        </div>
                                        <span id="Phoneerror" style="color: red;"></span>
                                    </div>


                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted" for="sel1">Recipe Type</label>
                                        <select class="form-control shadow-none rounded-0 mt-3 htt1" class="selRecipeType" id="selRecipeType" style="border: 2px solid white;">
                                            <option selected>vegitarian</option>
                                            <option>none vegitarian</option>
                                            <option>vegan</option>
                                        </select>
                                        <span id="RecipeTypeerror" style="color: red;"></span>
                                    </div>

                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted pb-1">Recipe Details</label>
                                        <div class="custom-file shadow-none form-control-lg mt-3">
                                            <input type="file" class="custom-file-input shadow-none" class="customFileRecipeDetails" id="customFileRecipeDetails">
                                            <label class="custom-file-label shadow-none rounded-0 brd1" for="customFile" id="brdRecipeDetails" style="border: 1px solid #f2f2f2;">Choose file</label>
                                        </div>
                                        <span id="RecipeDetailserror" style="color: red;"></span>
                                    </div>
                                    <div class="form-group col-lg-4 col-md-6 mt-4">
                                        <label class="text-muted pb-1">Recipe Images</label>
                                        <div class="custom-file shadow-none form-control-lg mt-3">
                                            <input type="file" class="custom-file-input shadow-none" class="customFileRecipeImages" id="customFileRecipeImages">
                                            <label class="custom-file-label shadow-none rounded-0 brd1" for="customFile" id="brdRecipeImages" style="border: 1px solid #f2f2f2;">Choose file</label>
                                        </div>
                                        <span id="RecipeImageserror" style="color: red;"></span>
                                    </div>
                                </div>

                                <div class="form-group mt-4">
                                    <label class="text-muted">Recipe Name</label>
                                    <div class="bg-white p-2 mt-3" id="brdRecipeName" style="border: 2px solid white;">
                                        <input type="text" placeholder="Recipe Name" name="txtRecipeName" id="txtRecipeName" class="form-control border-0 shadow-none">
                                    </div>
                                    <span id="RecipeNameerror" style="color: red;"></span>
                                </div>

                                <div class="form-group mt-4 pt-3">
                                    <label class="text-muted">Short Description</label>
                                    <textarea name="txtShortDescription" id="txtShortDescription" class="form-control p-2 rounded-0 shadow-none mt-3 pl-3" rows="5" placeholder="Short Description" style="border: 2px solid white;"></textarea>
                                    <span id="ShortDescriptionerror" style="color: red;"></span>
                                </div>

                                <div class="form-group mt-4 pt-3">
                                    <label class="text-muted">Message</label>
                                    <textarea name="txtMessage" id="txtMessage" class="form-control p-2 rounded-0 shadow-none mt-3 pl-3" rows="5" placeholder="Message" style="border: 2px solid white;"></textarea>
                                    <span id="Messageerror" style="color: red;"></span>
                                </div>
                                <div class="mt-4 pt-2">
                                    <input type="submit" value="Submit Recipe" class="btn btn-danger shadow rounded-0 p-3 px-4 bg-gold">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<!--<script src="assets/js/submit-recipe.js"></script> -->


<script>
    document.getElementById("frmSubmitRecipe").addEventListener('submit', SubmitRecipe_validate);
    function SubmitRecipe_validate(event) {
        event.preventDefault();
        var name = document.getElementById("txtName").value;
        var email = document.getElementById("txtEmail").value;
        var phone = document.getElementById("txtPhone").value;
        var recipe_type = document.getElementById("selRecipeType").value;
        var recipe_details = document.getElementById("customFileRecipeDetails").value;
        var recipe_images = document.getElementById("customFileRecipeImages").value;
        var recipe_name = document.getElementById("txtRecipeName").value;
        var description = document.getElementById("txtShortDescription").value;
        var message = document.getElementById("txtMessage").value;

        //check email is valid
        function EmailValidate() {
            // /^w.+@[a-zA-Z_-]+?.[a-zA-Z]{2,3}$/
            var numericExpression = /^[a-zA-Z_-].+@[a-zA-Z_-]+?.[a-zA-Z]{2,3}$/;
            if (email.match(numericExpression))
                {
                    return true;
                }
            else
                {
                    return false;
                }
        }

        if ((name.length <= 0) || (email.length <= 0) || (recipe_type.length <= 0) || (recipe_details.length <= 0) || (recipe_images.length <= 0) || (recipe_name.length <= 0) || (description.length <= 0) || (message.length <= 0)) {

            if (name.length <= 0) {
                document.getElementById("Nameerror").innerHTML = "Please Enter You Name";
                document.getElementById("brdName").style.borderColor = "red";
            } else {
                document.getElementById("Nameerror").innerHTML = "";
                document.getElementById("brdName").style.borderColor = "green";
            }


            if (email.length <= 0) {
                document.getElementById("Emailerror").innerHTML = "Please Enter Your Email";
                document.getElementById("brdEmail").style.borderColor = "red";
            } 
            else if (!(EmailValidate())) {
                document.getElementById("Emailerror").innerHTML = "Invalid email address";
                document.getElementById("brdEmail").style.borderColor = "red";
            } 
            else {
                document.getElementById("Emailerror").innerHTML = "";
                document.getElementById("brdEmail").style.borderColor = "green";
            }


            if (phone.length == 0) {
                document.getElementById("Phoneerror").innerHTML = "Please Enter Your Phone Number";
                document.getElementById("brdPhone").style.borderColor = "red";
              } 
              else if (phone.length <=9) {
                document.getElementById("Phoneerror").innerHTML = "Please Enter Your 10 Digit Phone Number";
                document.getElementById("brdPhone").style.borderColor = "red";
              }
              else if(!$.isNumeric(phone)){
                document.getElementById("Phoneerror").innerHTML = "please filled the maric number";
                document.getElementById("brdPhone").style.borderColor = "red";
              }
              else {
                document.getElementById("Phoneerror").innerHTML = "";
                document.getElementById("brdPhone").style.borderColor = "green";
              }


            if (recipe_type.length <= 0) {
                document.getElementById("RecipeTypeerror").innerHTML = "Please Enter Your Recipe Type";
                document.getElementById("selRecipeType").style.borderColor = "red";
            } else {
                document.getElementById("RecipeTypeerror").innerHTML = "";
                document.getElementById("selRecipeType").style.borderColor = "green";
            }


            if (recipe_details.length <= 0) {
                document.getElementById("RecipeDetailserror").innerHTML = "Please Enter Your Recipe Details";
                document.getElementById("brdRecipeDetails").style.borderColor = "red";
            } else {
                document.getElementById("RecipeDetailserror").innerHTML = "";
                document.getElementById("brdRecipeDetails").style.borderColor = "green";
            }


            if (recipe_images.length <= 0) {
                document.getElementById("RecipeImageserror").innerHTML = "Please Enter Your Recipe Images";
                document.getElementById("brdRecipeImages").style.borderColor = "red";
            } else {
                document.getElementById("RecipeImageserror").innerHTML = "";
                document.getElementById("brdRecipeImages").style.borderColor = "green";
            }


            if (recipe_name.length <= 0) {
                document.getElementById("RecipeNameerror").innerHTML = "Please Enter Your Recipe Name";
                document.getElementById("brdRecipeName").style.borderColor = "red";
            } else {
                document.getElementById("RecipeNameerror").innerHTML = "";
                document.getElementById("brdRecipeName").style.borderColor = "green";
            }


            if (description.length <= 0) {
                document.getElementById("ShortDescriptionerror").innerHTML = "Please Enter Your ShortDescription";
                document.getElementById("txtShortDescription").style.borderColor = "red";
            } else {
                document.getElementById("ShortDescriptionerror").innerHTML = "";
                document.getElementById("txtShortDescription").style.borderColor = "green";
            }


            if (message.length <= 0) {
                document.getElementById("Messageerror").innerHTML = "Please Enter Your Message";
                document.getElementById("txtMessage").style.borderColor = "red";
            } else {
                document.getElementById("Messageerror").innerHTML = "";
                document.getElementById("txtMessage").style.borderColor = "green";
            }
        } else {
            document.getElementById("Nameerror").innerHTML = "";
            document.getElementById("Emailerror").innerHTML = "";
            document.getElementById("Phoneerror").innerHTML = "";
            document.getElementById("RecipeTypeerror").innerHTML = "";
            document.getElementById("RecipeDetailserror").innerHTML = "";
            document.getElementById("RecipeImageserror").innerHTML = "";
            document.getElementById("RecipeNameerror").innerHTML = "";
            document.getElementById("ShortDescriptionerror").innerHTML = "";
            document.getElementById("Messageerror").innerHTML = "";
            
            document.getElementById("brdName").style.borderColor = "green";
            document.getElementById("brdEmail").style.borderColor = "green";
            document.getElementById("brdPhone").style.borderColor = "green";
            document.getElementById("selRecipeType").style.borderColor = "green";
            document.getElementById("brdRecipeDetails").style.borderColor = "green";
            document.getElementById("brdRecipeImages").style.borderColor = "green";
            document.getElementById("brdRecipeName").style.borderColor = "green";
            document.getElementById("txtShortDescription").style.borderColor = "green";
            document.getElementById("txtMessage").style.borderColor = "green";
            document.getElementById("txtMessage").style.borderColor = "green";
            /* allert("success") */

            var formdata = new FormData();
            formdata.append('', name);
            formdata.append('', email);
            formdata.append('', phone);
            formdata.append('', recipe_type);
            formdata.append('', recipe_details);
            formdata.append('', recipe_images);
            formdata.append('', recipe_name);
            formdata.append('', description);
            formdata.append('', message);

            fetch('', {
                method: 'POST',
                body: formdata
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.message_type == 'error') {
                        alert(data.message)
                    } else {
                        alert(data.message)
                    }
                })
                .catch(function (error) {
                    console.log('Request Failed' + error);
                });
        }
    }
</script>

</body>
</html>