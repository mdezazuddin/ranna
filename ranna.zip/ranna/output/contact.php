<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        <!-- section1 -->
        <section class="section1 bg-gold">
            <div class="container pt-5 pb-5">
                <div class="row pt-5 pb-5">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white h2 font-weight-bold left-reveal">Contact</h1>
                        <h6 class="mt-4 right-reveal">
                            <a class="clr-red mr-2 text-light text-decoration-none" href="#"><i class="fa fa-home mr-2"></i>Home</a> 
                            <span class="text-light"> <small><i class="fa fa-chevron-right fa-sm mr-2"></i></small> Contact </span>
                        </h6>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- section2 -->
        <section class="section2">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-6 py-5 pl-md-5 pr-md-5">
                        <div class="pl-md-4">
                            <div class="left-reveal">
                                <h4 class="mt-5"><b>Our Address</b></h4>
                                <div class="progress mt-3" style="height: 2px;">
                                    <div class="progress-bar bg-gold" style="width:10%;"></div>
                                </div>
                            </div>
                            <p class="mt-4 right-reveal">Korem ipsum dolor sitter amet consectetuer adipiscing elitter Curabt ur ugueque habitant morbi tristique.</p>

                            <p class="mt-4 left-reveal">
                                <span class="fa-stack fa-lg mr-2">
                                    <i class="fa fa-circle fa-stack-2x text-gold"></i>
                                    <i class="fa fa-map-marker fa-stack-1x text-white"></i>
                                </span>
                                <span>29 Street, Melbourne City, Australia # 34 Road, House #10.</span>
                            </p>
                            <p class="right-reveal">
                                <span class="fa-stack fa-lg mr-2">
                                    <i class="fa fa-circle fa-stack-2x text-gold"></i>
                                    <i class="fa fa-phone fa-stack-1x text-white"></i>
                                </span>
                                <a href="tel:+123-5889-000" class="text-decoration-none mr-5 text-hvr">
                                    +123-5889-000
                                </a>
                            </p>
                            <p class="left-reveal">
                                <span class="fa-stack fa-lg mr-2">
                                    <i class="fa fa-circle fa-stack-2x text-gold"></i>
                                    <i class="fa fa-phone fa-stack-1x text-white"></i>
                                </span>
                                <a href="tel:+123-5889-000" class="text-decoration-none mr-5 text-hvr">
                                    +987-5889-000
                                </a>
                            </p>
                            <p class="right-reveal">
                                <span class="fa-stack fa-lg mr-2">
                                    <i class="fa fa-circle fa-stack-2x text-gold"></i>
                                    <i class="fa fa-envelope fa-stack-1x text-white"></i>
                                </span>
                                <a href="mailto:info@example.com" class="text-decoration-none mr-5 text-hvr">
                                    info@example.com
                                </a>
                            </p>
                        </div>

                        <div class="pl-md-4">
                            <h4 class="mt-5"><b>Send Us Message</b></h4>
                            <div class="progress mt-3" style="height: 2px;">
                                <div class="progress-bar bg-gold" style="width:10%;"></div>
                            </div>

                            <form name="frmContact" id="frmContact" method="post" action="#">
                                <div class="row">
                                    <div class="form-group col-md-6 mt-4">
                                        <div class="border border-muted p-2">
                                            <input type="text" placeholder="Name" name="txtName" id="txtName" class="form-control border-0 shadow-none">
                                        </div>
                                        <span id="Nameerror" style="color: red;"></span>
                                    </div>
                                    <div class="form-group col-md-6 mt-4">
                                        <div class="border border-muted p-2">
                                            <input type="text" placeholder="Subject" name="txtSubject" id="txtSubject" class="form-control border-0 shadow-none">
                                        </div>
                                        <span id="Subjecterror" style="color: red;"></span>
                                    </div>
                                </div>
                                <div class="form-group mt-2">
                                    <div class="border border-muted p-2">
                                        <input type="text" placeholder="Email" name="txtEmail" id="txtEmail" class="form-control border-0 shadow-none">
                                    </div>
                                    <span id="Emailerror" style="color: red;"></span>
                                </div>
                                <div class="form-group mt-4">
                                    <textarea name="txtMessage" id="txtMessage" class="form-control p-2 rounded-0 shadow-none" rows="5" placeholder="Message"></textarea>
                                    <span id="Messageerror" style="color: red;"></span>
                                </div>
                                <div class="form-group mt-4">
                                    <input type="submit" value="SEND MESSAGE" class="btn btn-danger rounded-0 p-3 px-4 bg-gold">
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- google-map -->
                    <div class="col-12 col-lg-6 p-md-0">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.0721376413476!2d-73.73979336718509!3d40.7164284386799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c263d234963e1f%3A0xb8c246c12c49cdc6!2s217-44%2098th%20Ave%2C%20Queens%20Village%2C%20NY%2011429%2C%20USA!5e0!3m2!1sen!2sin!4v1583386875157!5m2!1sen!2sin"
        width="100%" height="100%" frameborder="0" style="margin: 0;" allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>      
<!--<script src="assets/js/contact.js"></script> -->

<script>
    document.getElementById("frmContact").addEventListener('submit', Contact_validate);
    function Contact_validate(event) {
        event.preventDefault();

        var name = document.getElementById("txtName").value;
        var subject = document.getElementById("txtSubject").value;
        var email = document.getElementById("txtEmail").value;
        var message = document.getElementById("txtMessage").value;

        //check email is valid
        function EmailValidate() {
            // /^w.+@[a-zA-Z_-]+?.[a-zA-Z]{2,3}$/
            var numericExpression = /^[a-zA-Z_-].+@[a-zA-Z_-]+?.[a-zA-Z]{2,3}$/;
            if (email.match(numericExpression))
                {
                    return true;
                }
            else
                {
                    return false;
                }
        }
        
        if ((name.length <= 0) || (subject.length <= 0) || (email.length <= 0) || (message.length <= 0)) {

            if (name.length <= 0) {
                document.getElementById("Nameerror").innerHTML = "Please Enter You Name";
            } else {
                document.getElementById("Nameerror").innerHTML = "";
            }

            if (subject.length <= 0) {
                document.getElementById("Subjecterror").innerHTML = "Please Enter Your Subject";
            } else {
                document.getElementById("Subjecterror").innerHTML = "";
            }

            if (email.length <= 0) {
                document.getElementById("Emailerror").innerHTML = "Please Enter Your Email";
            }
            else if (!(EmailValidate())) {
                document.getElementById("Emailerror").innerHTML = "Invalid email address";
            } 
            else {
                document.getElementById("Emailerror").innerHTML = "";
            }


            if (message.length <= 0) {
                document.getElementById("Messageerror").innerHTML = "Please Enter Your Message";
            } else {
                document.getElementById("Messageerror").innerHTML = "";
            }
        } else {
            document.getElementById("Nameerror").innerHTML = "";
            document.getElementById("Subjecterror").innerHTML = "";
            document.getElementById("Emailerror").innerHTML = "";
            document.getElementById("Messageerror").innerHTML = "";


            /* alert("success")
            var formdata = new FormData();
            formdata.append('', name);
            formdata.append('', subject);
            formdata.append('', email);
            formdata.append('', message)

            fetch('', {
                method: 'POST',
                body: formdata
            })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.message_type == 'error') {
                    alert(data.message)
                } else {
                    alert(data.message)
                }
            })
            .catch(function (error) {
                console.log('Request Failed' + error);
            }); */
        }
    }
</script>

</body>
</html>